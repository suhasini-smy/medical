    <!-- Modal -->
    <div class="modal fade" id="ajax-modal" style="display:none" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">Modal Header</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <form id="userForm" name="userForm" class="form-horizontal">
               <input type="hidden" name="user_id" id="user_id">
                <div class="form-group">
                    <label for="name" class="col-sm-6 control-label">Visited date</label>
                    <div class="col-sm-12">
                        <input type="text" class="form-control" id="visited_date" name="visited_date" placeholder="Enter Name" value="" maxlength="50" required="">
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-6 control-label">Next Visit date</label>
                    <div class="col-sm-12">
                        <input type="email" class="form-control" id="next_visit_date" name="next_visit_date" placeholder="Enter Email" value="" required="">
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-6 control-label">status</label>
                    <div class="col-sm-12">
                    <select class="form-select form-control form-control-brdr" name="is_active" id="is_active">
                        <option value="1">Active</option>
                        <option value="2">In Active</option>
                    </select>
                    </div>

                </div>
            </form>

        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </div>

    </div>
    </div>
<?php /**PATH C:\xampp\htdocs\vishal-hospital\resources\views///patient/update-model.blade.php ENDPATH**/ ?>